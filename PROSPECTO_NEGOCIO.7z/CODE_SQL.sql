--create or replace table catalog_lhcl_prod_bcp.bcp_edv_sbxm_006_v.tp_detallenegociodeuda_recrea_202407 as
with
tp_cortemes_pdm as (
    select max(fecdia) as fecdia
    from catalog_lhcl_prod_bcp.bcp_udv_int_v.h_deudorsbsdetalle
    where fecdia between '2023-08-01' and '2024-08-01'
    group by year(fecdia)*100+month(fecdia)
)
,h_deudorsbsdetalle as (
    select *
    from catalog_lhcl_prod_bcp.bcp_udv_int_v.h_deudorsbsdetalle
    where fecdia in (select fecdia from tp_cortemes_pdm)
)
,tp_pdm_detallenegociodeuda as (
    select
    date_format(cast(a.fecdia as date), 'yyyyMM') as codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    substr(a.codctacontablesbs,1,2) as tipcredito,
    sum(a.mtodeudasol) as mtodeudasol
    from h_deudorsbsdetalle a
    where --fecdia in (select fecdia from tp_cortemes_pdm)
    substr(a.codctacontablesbs,1,2)='14'
    and substr(a.codctacontablesbs,4,1) in ('1','3','4','5','6')
    and substr(a.codctacontablesbs,5,2) not in ('03','04') 
    group by
    date_format(cast(a.fecdia as date), 'yyyyMM'),
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    substr(a.codctacontablesbs,1,2)

    union

    select
    date_format(cast(a.fecdia as date), 'yyyyMM') codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    substr(a.codctacontablesbs,1,2) as tipcredito,
    sum(a.mtodeudasol) as mtodeudasol
    from h_deudorsbsdetalle a
    where
    substr(a.codctacontablesbs,1,2)='71'
    and substr(a.codctacontablesbs,4,1) in ('1','2','3','4')
    group by
    date_format(cast(a.fecdia as date), 'yyyyMM'),
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    substr(a.codctacontablesbs,1,2)
)
,tp_pdm_detallenegociodeuda_2 as(
    select
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    substr(a.codctacontablesbs,1,2) as tipcredito,
   mtodeudasol
   from tp_pdm_detallenegociodeuda a
)
,tp_pdmclientesbdn_2 as (
    select date_format(cast(a.fecdia as date), 'yyyyMM') codmes, a.codsector, a.codsectorista, b.codclavepartycli
    from catalog_lhcl_prod_bcp.bcp_udv_int_v.h_sectorista a
    inner join catalog_lhcl_prod_bcp.bcp_udv_int_v.h_cliente b on b.fecdia in (select fecdia from tp_cortemes_pdm) 
        and a.fecdia = b.fecdia and a.codsector = b.codsector
    where
    a.fecdia in (select fecdia from tp_cortemes_pdm)
    and trim(a.codbcasectorista) = 'NEG'
    and trim(a.codsector) not in ('.', '0000G9')
)
,tp_pdm_detallenegociodeuda_3 as (
    select
    distinct
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codclavepartydeudorsbs,
    a.codctacontablesbs,
    a.tiproldeudorsbs,
    a.tipcredito,
    case when b.codclavepartycli is not null then 'CARTERIZADO' else 'NO_CLIENTES' end as flg_cliente,
    a.mtodeudasol
    from tp_pdm_detallenegociodeuda_2 a
    left outer join tp_pdmclientesbdn_2 b on a.codmes=b.codmes and a.codclavepartycli=b.codclavepartycli
)
,tp_cliente_saldoprodsofisticado as (
    select
    year(fecdia)*100+month(fecdia) as codmes
    ,codsbs
    ,codclavepartycli
    from h_deudorsbsdetalle
    where --fecdia in (select fecdia from tp_cortemes_pdm)
    (substring(codctacontablesbs,1,2)='14'
    and substring(codctacontablesbs,4,1) in ('1','3','4')
    and substring(codctacontablesbs,5,2) not in ('03','04')
    and substring(codctacontablesbs,7,2) not in ('02','06'))
    and mtodeudasol > 0
    and codctacontablesbs not in (select * from catalog_lhcl_prod_bcp.bcp_edv_sbxm_006.tp_nocuentascontables)
    and codclavepartycli is not null
    group by year(fecdia)*100+month(fecdia),codsbs,codclavepartycli
    union
    select
    year(fecdia)*100+month(fecdia) as codmes
    ,codsbs
    ,codclavepartycli
    from h_deudorsbsdetalle
    where --fecdia in (select fecdia from tp_cortemes_pdm)
    (substring(codctacontablesbs,1,2)='71'
    and substring(codctacontablesbs,4,1) in ('1','2','3','4'))
    and mtodeudasol > 0
    and codctacontablesbs not in (select * from catalog_lhcl_prod_bcp.bcp_edv_sbxm_006.tp_nocuentascontables)
    group by year(fecdia)*100+month(fecdia),codsbs,codclavepartycli
)
,tp_pdm_neg_deuda_reactiva_bcp as (
    select year(fecdia)*100+month(fecdia) as codmes
    ,a.codclavepartycli
    ,nvl(sum(case when concat(substr(codctacontablefin,1,2),substr(codctacontablefin,4,1))='141'
              then a.mtosaldodia else 0 end),0) as mtosaldofinmesvigsol
    from catalog_lhcl_prod_bcp.bcp_ddv_pycf_cubowu_v.f_reportegestion a
    where fecdia in (select fecdia from tp_cortemes_pdm)
    and trim(a.tipctacontable) = 'A'
    and a.tipllavemoneda = 1
    and codproductofin in ('PAGFFC', 'CCOCTB', 'PAGFF2')
    and (a.codctacontablefin not like '1418%') and (a.codctacontablefin not like '1428%')
    and trim(a.codestadomorosidad) in ('ESVIG', 'ESVEN', 'ESJUD')
    and trim(a.codfuentedato) in ('ALS','COBT','CSCC','CSCO','WLEA','CTAO', 'BKTD','CSCB','VPLU')
    group by year(fecdia)*100+month(fecdia),a.codclavepartycli
)
,tp_pdm_deuda_reactiva as (
    select
    year(fecdia)*100+month(fecdia) as codmes
    ,codsbs
    ,codclavepartycli
    ,codempsistemafinanciero
    ,sum(mtodeudasol) as mtodeudasol_reactiva
    from h_deudorsbsdetalle
    where --fecdia in (select fecdia from tp_cortemes_pdm)
    codctacontablesbs like '81_8%'
    and substring(codctacontablesbs,5,2) in ('01','11')
    and codclavepartycli is not null
    group by year(fecdia)*100+month(fecdia),codsbs,codclavepartycli,codempsistemafinanciero
)
,tp_saldoprodsofisticado_1 as (
    select year(fecdia)*100+month(fecdia) as codmes,codsbs,codclavepartycli
    ,codempsistemafinanciero
    ,sum(mtodeudasol) as mtodeudasol
    from h_deudorsbsdetalle
    where --fecdia in (select fecdia from tp_cortemes_pdm)
    substring(codctacontablesbs,1,2)='14'
    and substring(codctacontablesbs,4,1) in ('1','3','4')
    and substring(codctacontablesbs,5,2) not in ('03','04')
    and codempsistemafinanciero not in ('00061','00099')
    and codclavepartycli is not null
    group by year(fecdia)*100+month(fecdia),codsbs,codclavepartycli,codempsistemafinanciero
)
,tp_saldoprodsofisticadoneg_1_reactiva as (
    select a.codmes,a.codclavepartycli,a.codsbs,a.codempsistemafinanciero
    ,a.mtodeudasol
    ,coalesce(b.mtodeudasol_reactiva,0) as mtodeudasol_reactiva
    ,a.mtodeudasol - coalesce(b.mtodeudasol_reactiva,0) as mtodeudasol_sinreactiva 
    from tp_saldoprodsofisticado_1 a
    left join tp_pdm_deuda_reactiva b on a.codmes=b.codmes and a.codclavepartycli=b.codclavepartycli 
          and a.codsbs=b.codsbs and a.codempsistemafinanciero = b.codempsistemafinanciero
)
,tp_saldoprodsofisticadoneg_1_reactiva_bcp as (
    select codmes,codclavepartycli,codsbs,codempsistemafinanciero
    ,mtodeudasol
    ,mtodeudasol_reactiva
    ,mtodeudasol_sinreactiva
    from tp_saldoprodsofisticadoneg_1_reactiva
    where codempsistemafinanciero = '00001'
)
,tp_saldoprodsofisticadoneg_1_reactiva_bcp_2 as (
    select a.codmes,a.codclavepartycli,a.codsbs,a.codempsistemafinanciero
    ,a.mtodeudasol
    ,a.mtodeudasol_reactiva
    ,a.mtodeudasol_sinreactiva
    ,sum(coalesce(b.mtosaldofinmesvigsol,0)) as mtosaldofinmesvigsol
    from tp_saldoprodsofisticadoneg_1_reactiva_bcp a --tp_saldoprodsofisticadoneg_1_reactiva_bcp
    left join tp_pdm_neg_deuda_reactiva_bcp b on a.codmes=b.codmes and a.codclavepartycli=b.codclavepartycli
    group by a.codmes,a.codclavepartycli,a.codsbs,a.codempsistemafinanciero
    ,a.mtodeudasol,a.mtodeudasol_reactiva,a.mtodeudasol_sinreactiva
)
,tp_saldoprodsofisticadoneg_1_reactiva_bcp_3 as (
    select codmes,codclavepartycli,codsbs,codempsistemafinanciero
    ,mtodeudasol
    ,case when codmes=202106 then coalesce(mtodeudasol_reactiva,0)
      else (case when codempsistemafinanciero='00001' and coalesce(mtosaldofinmesvigsol,0)<>coalesce(mtodeudasol_reactiva,0)
            then mtosaldofinmesvigsol else mtodeudasol_reactiva end) end as mtodeudasol_reactiva
    ,case when codmes=202106 then (mtodeudasol - coalesce(mtodeudasol_reactiva,0))
      else (case when codempsistemafinanciero='00001' and coalesce(mtosaldofinmesvigsol,0)<>coalesce(mtodeudasol_reactiva,0)
            then mtodeudasol - coalesce(mtosaldofinmesvigsol,0) else mtodeudasol - coalesce(mtodeudasol_reactiva,0) end) end as mtodeudasol_sinreactiva
    from tp_saldoprodsofisticadoneg_1_reactiva_bcp_2
)
,tp_saldoprodsofisticadoneg_1_reactiva_var as (
    select codmes,codclavepartycli,codsbs,codempsistemafinanciero
        ,mtodeudasol
        ,case when mtodeudasol_sinreactiva < 0 then coalesce(mtodeudasol,0) else mtodeudasol_reactiva end as mtodeudasol_reactiva
        ,case when mtodeudasol_sinreactiva < 0 then 0 else mtodeudasol_sinreactiva end as mtodeudasol_sinreactiva
    from (
        select *
        from tp_saldoprodsofisticadoneg_1_reactiva
        where codempsistemafinanciero <> '00001'
        union all
        select *
        from tp_saldoprodsofisticadoneg_1_reactiva_bcp_3 
        where codempsistemafinanciero = '00001'
    )

    union all

    select codmes,codclavepartycli,codsbs,codempsistemafinanciero
    ,null as mtodeudasol ,null as mtodeudasol_reactiva ,mtodeudasol as mtodeudasol_sinreactiva
    from (
        select year(fecdia)*100+month(fecdia) as codmes,codsbs,codclavepartycli,codempsistemafinanciero
        ,sum(mtodeudasol) as mtodeudasol
        from h_deudorsbsdetalle
        where --fecdia in (select fecdia from tp_cortemes_pdm)
        substring(codctacontablesbs,1,2)='71'
        and substring(codctacontablesbs,4,1) in ('1','2','3','4')
        and codempsistemafinanciero not in ('00061','00099')
        and codclavepartycli is not null
        group by year(fecdia)*100+month(fecdia),codsbs,codclavepartycli,codempsistemafinanciero
    )
)
,tp_saldoprodsofisticado_1_p as (
    select codmes ,codsbs ,codclavepartycli
    ,sum(mtodeudasol_sinreactiva) as mtodeudasol
    from tp_saldoprodsofisticadoneg_1_reactiva_var
    group by codmes,codsbs,codclavepartycli
)
,tp_saldoprodsofisticado_movil_1 as (
    select codmes
    ,codclavepartycli
    ,sum(mtodeudasol) as mtodeudasol
    from tp_saldoprodsofisticado_1_p
    group by codmes,codclavepartycli
)
,tp_saldoprodsofisticado_movil_2 as (
    select distinct a.codclavepartycli,a.codsbs,b.mtodeudamovil
    from tp_saldoprodsofisticado_1_p a
    left join (
    select
    codclavepartycli
    ,avg(case when nvl(mtodeudasol,0)=0 then 0 else nvl(mtodeudasol,0) end) as mtodeudamovil
    from tp_saldoprodsofisticado_movil_1
    group by codclavepartycli) b on a.codclavepartycli = b.codclavepartycli
)
,tp_saldoprodsofisticado_movil_3 as (
    select distinct a.codmes,a.codclavepartycli,a.codsbs,b.mtodeudamovil,b.flg_rango
    from tp_saldoprodsofisticado_1_p a --tiproldeudorsbs
    left join (
        select codclavepartycli,codsbs,mtodeudamovil
        ,case when mtodeudamovil>=700000 and mtodeudamovil<=1200000 then '1.[0.7MM-1.2MM]'
        else (case when mtodeudamovil>1200000 and mtodeudamovil<=10000000 then '2.<1.2MM-10MM]' 
        else 'OTROS' end) end as flg_rango
        from tp_saldoprodsofisticado_movil_2
    ) b on a.codclavepartycli = b.codclavepartycli and a.codsbs=b.codsbs
    where a.codmes=202407  ----referencia al ultimo codmes
)
,tp_pdm_detallenegociodeuda_4 as (
    select distinct
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codclavepartydeudorsbs,
    a.tiproldeudorsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codctacontablesbs,
    a.tipcredito,
    a.flg_cliente,
    a.mtodeudasol,
    b.mtodeudamovil,
    b.flg_rango
    from tp_pdm_detallenegociodeuda_3 a
    left join tp_saldoprodsofisticado_movil_3 b on a.codsbs=b.codsbs and a.codclavepartycli=b.codclavepartycli
) 
,tp_pdm_detallenegociodeuda_5 as (
    select
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codclavepartydeudorsbs,
    a.tiproldeudorsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.codctacontablesbs,
    a.tipcredito,
    a.mtodeudasol,
    b.codsector,
    case when a.flg_cliente='CARTERIZADO' then 'CARTERIZADO'
        when trim(b.codsector) is null or trim(b.codsector)='.' then 'NO_CLIENTES'
        when b.codsector in ('0000G1','0000G2','0000G6','0000G8','0000G9') then 'BOLSON' else 'OTROS' end as flg_cliente,
    a.mtodeudamovil,  
    case when a.mtodeudamovil is null then 'OTROS' else a.flg_rango end as flg_rango
    from tp_pdm_detallenegociodeuda_4 a
    left join catalog_lhcl_prod_bcp.bcp_udv_int_v.h_cliente b on b.fecdia = '2024-07-31' and a.codclavepartycli=b.codclavepartycli and a.codmes=date_format(cast(b.fecdia as date), 'yyyyMM')
    where b.fecdia = '2024-07-31' --referencia al ultimo dia del mes anterior cuando se ejecutó la tabla h_cliente
)
,tp_pdm_detallenegociodeuda_6_p as (
    select
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    a.codsbs,
    a.codclavepartydeudorsbs,
    a.tiproldeudorsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    b.tipclasifinternaparty,
    a.codctacontablesbs,
    a.tipcredito,
    a.mtodeudasol,
    a.codsector,
    a.flg_cliente,
    a.mtodeudamovil,
    a.flg_rango
    from tp_pdm_detallenegociodeuda_5 a
    left join catalog_lhcl_prod_bcp.bcp_udv_int_v.h_party b on b.fecdia = '2024-07-31' and a.codclavepartycli=b.codclaveparty and a.codmes=date_format(cast(b.fecdia as date), 'yyyyMM')
    --on a.codmes=date_format(cast(b.fecdia as date), 'yyyyMM') and a.codclavepartycli=b.codclaveparty
    where b.fecdia = '2024-07-31' --referencia al ultimo dia del mes anterior cuando se ejecutó la tabla h_party
)
,tp_cliente_saldoprodsofisticado_2 as ( 
    select codmes ,codclavepartycli ,codsbs
    from tp_cliente_saldoprodsofisticado
    group by codmes, codclavepartycli, codsbs
)
,tp_detallenegociodeuda_recrea_202407 as (
    select distinct
    a.codmes,
    a.codclavepartycli,
    a.codclaveunicocli,
    d.codinternocomputacional,
    a.codsbs,
    a.codclavepartydeudorsbs,
    a.tiproldeudorsbs,
    a.codempsistemafinanciero,
    a.nbrempsistemafinanciero,
    a.tipclasifinternaparty as tipper,
    a.codctacontablesbs,
    a.tipcredito,
    a.mtodeudasol,
    a.codsector,
    a.flg_cliente,
    case when a.codsbs=b.codsbs then 0 else 1 end as flg_clientebanco,
    case when a.codsbs=c.codsbs and a.codclavepartycli=c.codclavepartycli then 1 else 0 end as flg_prodsofistcdo,
    a.mtodeudamovil,
    a.flg_rango
    from tp_pdm_detallenegociodeuda_6_p a
    left join catalog_lhcl_prod_bcp.bcp_edv_sbxm_006.de_glosanocliente_2 b on a.codsbs=b.codsbs
    left join tp_cliente_saldoprodsofisticado_2 c on a.codsbs=c.codsbs and a.codclavepartycli=c.codclavepartycli
    left join catalog_lhcl_prod_bcp.bcp_udv_int_v.m_cliente d on a.codclavepartycli = d.codclavepartycli
)
SELECT 
A.CODMES,
A.CODSBS,
A.CODCLAVEPARTYDEUDORSBS,
A.TIPROLDEUDORSBS,
A.CODEMPSISTEMAFINANCIERO,
A.NBREMPSISTEMAFINANCIERO,
A.CODCLAVEPARTYCLI,
A.CODCLAVEUNICOCLI,
A.CODINTERNOCOMPUTACIONAL,
A.CODSECTOR,
SUM(A.MTODEUDASOL) AS DEUDAVIG 
from tp_detallenegociodeuda_recrea_202407 a
WHERE
A.FLG_CLIENTE='CARTERIZADO'
AND A.TIPCREDITO=14  --DEUDA DIRECTA
AND A.CODMES =202407 --REFERENCIA AL MES ANTERIOR TOMANDO EN CUENTA QUE LA EJECUCION SON EL 28 O 29 DE CADA MES
GROUP BY 
A.CODMES,
A.CODSBS,
A.CODCLAVEPARTYDEUDORSBS,
A.TIPROLDEUDORSBS,
A.CODEMPSISTEMAFINANCIERO,
A.NBREMPSISTEMAFINANCIERO,
A.CODCLAVEPARTYCLI,
A.CODCLAVEUNICOCLI,
A.CODINTERNOCOMPUTACIONAL,
A.CODSECTOR
UNION
---2.NO CLIENTE Y BOLSON - RANGO 1:
SELECT 
B.CODMES,
B.CODSBS,
B.CODCLAVEPARTYDEUDORSBS,
B.TIPROLDEUDORSBS,
B.CODEMPSISTEMAFINANCIERO,
B.NBREMPSISTEMAFINANCIERO,
B.CODCLAVEPARTYCLI,
B.CODCLAVEUNICOCLI,
B.CODINTERNOCOMPUTACIONAL,
B.CODSECTOR,
SUM(B.MTODEUDASOL) AS DEUDAVIG 
from tp_detallenegociodeuda_recrea_202407 b
WHERE
B.FLG_CLIENTE IN ('NO_CLIENTES','BOLSON')  --NO CLIENTES Y BOLSON
AND B.FLG_RANGO='1.[0.7MM-1.2MM]' --DEUDA PROMEDIO SIN CONSIDERAR PRODUCTOS DE MINORISTA
AND B.TIPPER='E'  --CLIENTE MINORISTA
AND B.FLG_PRODSOFISTCDO=1  --CR?DITOS QUE NO SON PRESTAMOS NI TC (SOBREGIROS / DESCUENTOS, ETC)
AND B.FLG_CLIENTEBANCO=1   --NO CLIENTE BANCO
AND B.TIPCREDITO=14  --DEUDA DIRECTA
AND B.CODMES =202407 --REFERENCIA AL MES ANTERIOR TOMANDO EN CUENTA QUE LA EJECUCION SON EL 28 O 29 DE CADA MES
GROUP BY 
B.CODMES,
B.CODSBS,
B.CODCLAVEPARTYDEUDORSBS,
B.TIPROLDEUDORSBS,
B.CODEMPSISTEMAFINANCIERO,
B.NBREMPSISTEMAFINANCIERO,
B.CODCLAVEPARTYCLI,
B.CODCLAVEUNICOCLI,
B.CODINTERNOCOMPUTACIONAL,
B.CODSECTOR
UNION
---3.NO CLIENTE Y BOLSON - RANGO 2:
SELECT 
C.CODMES,
C.CODSBS,
C.CODCLAVEPARTYDEUDORSBS,
C.TIPROLDEUDORSBS,
C.CODEMPSISTEMAFINANCIERO,
C.NBREMPSISTEMAFINANCIERO,
C.CODCLAVEPARTYCLI,
C.CODCLAVEUNICOCLI,
C.CODINTERNOCOMPUTACIONAL,
C.CODSECTOR,
SUM(C.MTODEUDASOL) AS DEUDAVIG
from tp_detallenegociodeuda_recrea_202407 c
WHERE
C.FLG_CLIENTE IN ('NO_CLIENTES','BOLSON')  --NO CLIENTES Y BOLSON
AND C.FLG_RANGO='2.<1.2MM-10MM]'  --DEUDA PROMEDIO SIN CONSIDERAR PRODUCTOS DE MINORISTA
AND C.FLG_PRODSOFISTCDO=1  --CR?DITOS QUE NO SON PRESTAMOS NI TC (SOBREGIROS / DESCUENTOS, ETC)
AND C.FLG_CLIENTEBANCO=1  --NO CLIENTE BANCO
AND C.TIPCREDITO=14  --DEUDA DIRECTA
AND C.CODMES =202407 --REFERENCIA AL MES ANTERIOR TOMANDO EN CUENTA QUE LA EJECUCION SON EL 28 O 29 DE CADA MES  
GROUP BY
C.CODMES,
C.CODSBS,
C.CODCLAVEPARTYDEUDORSBS,
C.TIPROLDEUDORSBS,
C.CODEMPSISTEMAFINANCIERO,
C.NBREMPSISTEMAFINANCIERO,
C.CODCLAVEPARTYCLI,
C.CODCLAVEUNICOCLI,
C.CODINTERNOCOMPUTACIONAL,
C.CODSECTOR
;