# Databricks notebook source
# coding: utf-8
# **********************************************************************************************************************
# || PROYECTO       : Prospecto Ingreso BDN
# || NOMBRE         : ADRMMGR_HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN.py
# || TABLA DESTINO  : BCP_DDV_ADRMMGR_SEGINFOBCANEG.HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN
# || TABLA FUENTE   : CATALOG_LHCL_PROD_BCP.BCP_UDV_INT_V.H_DEUDORSBSDETALLE
# ||                : CATALOG_LHCL_PROD_BCP.BCP_UDV_INT_V.H_SECTORISTA
# ||                : CATALOG_LHCL_PROD_BCP.BCP_DDV_MATRIZVARIABLES_V.HM_DETCONCEPTORESUMENSALDO
# ||                : CATALOG_LHCL_PROD_BCP.BCP_EDV_SBXM_006.TP_NOCUENTASCONTABLES
# ||                : CATALOG_LHCL_PROD_BCP.BCP_UDV_INT_V.H_CLIENTE
# ||                : CATALOG_LHCL_PROD_BCP.BCP_UDV_INT_V.H_DEUDORSBSDETALLE
# ||                : CATALOG_LHCL_PROD_BCP.BCP_UDV_INT_V.H_PARTY
# || OBJETIVO       : INSERTAR DATOS A TABLA PRODUCTIVA HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN
# || TIPO           : PYSPARK
# || REPROCESABLE   : SI - RERUN
# || OBSERVACION    : NA
# || SCHEDULER      : NA
# || JOB            : @P4LKLC4
# || VERSION   DESARROLLADOR        PROVEEDOR      PO                  FECHA             DESCRIPCION
# || -------------------------------------------------------------------------------------------------------------------
# || 1.0.0     JULIAN VALERA        BCP            STEFANNY SEDANO     2024-09-25        PROCESO HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN
# **********************************************************************************************************************
from datetime import datetime, timedelta
from functools import reduce

from dateutil import rrule
from dateutil.relativedelta import relativedelta
from pyspark import StorageLevel
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, max, year, month
from pyspark.sql.types import StructType, StructField, StringType, DecimalType, TimestampType, DateType


# COMMAND ----------
# MAGIC %md
# MAGIC Seccion Import
# COMMAND ----------

# COMMAND ----------

# MAGIC %md
# MAGIC Seccion Proceso

# COMMAND ----------


class ProspectoIngresoBDN:
    def __init__(self, prms_spark):
        """
        Logica de proceso para DTI Producto Activo
        """
        self.fechas = []
        self.periodos = None
        self.codmes_fin = None
        self.codmes_inicio = None
        self.last_day = None
        self.first_day = None
        self.codmes_proceso = None
        self.spark = SparkSession.builder.getOrCreate()
        self.spark.conf.set("spark.sql.session.timeZone", "America/Lima")
        # self.prm_spark_fecharutina = prms_spark["prm_spark_fecharutina"]
        self.prm_spark_fecharutina = '2024-08-31'

        # self.prm_spark_esquema_ddv_seginfobcaneg = prms_spark["prm_spark_esquema_ddv_seginfobcaneg"]
        # self.prm_spark_esquema_ddv_matrizvariables = prms_spark["prm_spark_esquema_ddv_matrizvariables"]
        # self.prm_spark_esquema_ddv_infconsolidadocli = prms_spark["prm_spark_esquema_ddv_infconsolidadocli"]
        # self.prm_spark_esquema_udv_int = prms_spark["prm_spark_esquema_udv_int"]


        # self.prm_spark_tabla_h_deudorsbsdetalle = prms_spark["prm_spark_tabla_h_deudorsbsdetalle"]
        # self.prm_spark_tabla_h_sectorista = prms_spark["prm_spark_tabla_h_sectorista"]
        # self.prm_spark_tabla_h_cliente = prms_spark["prm_spark_tabla_h_cliente"]
        # self.prm_spark_tabla_h_party = prms_spark["prm_spark_tabla_h_party"]
        # self.prm_spark_tabla_hm_detconceptoresumensaldo = prms_spark["prm_spark_tabla_hm_detconceptoresumensaldo"]
        # self.prm_spark_tabla_hm_insumopuntuacionprospectoingresobdn = prms_spark["prm_spark_tabla_hm_insumopuntuacionprospectoingresobdn"]
        # self.prm_spark_tabla_mm_parametrogeneral = prms_spark["prm_spark_tabla_mm_parametrogeneral"]

        # self.cons_h_deudorsbsdetalle = f"{self.prm_spark_esquema_udv_int}.{self.prm_spark_tabla_h_deudorsbsdetalle}"
        # self.cons_h_sectorista = f"{self.prm_spark_esquema_udv_int}.{self.prm_spark_tabla_h_sectorista}"
        # self.cons_h_cliente = f"{self.prm_spark_esquema_udv_int}.{self.prm_spark_tabla_h_cliente}"
        # self.cons_h_party = f"{self.prm_spark_esquema_udv_int}.{self.prm_spark_tabla_h_party}"
        # self.cons_hm_detconceptoresumensaldo = f"{self.prm_spark_esquema_ddv_matrizvariables}.{self.prm_spark_tabla_hm_detconceptoresumensaldo}"
        # self.cons_hm_insumopuntuacionprospectoingresobdn = f"{self.prm_spark_esquema_ddv_seginfobcaneg}.{self.prm_spark_tabla_hm_insumopuntuacionprospectoingresobdn}"
        # self.cons_mm_parametrogeneral = f"{self.prm_spark_esquema_ddv_infconsolidadocli}.{self.prm_spark_tabla_mm_parametrogeneral}"

        self.cons_h_deudorsbsdetalle = prms_spark['prm_spark_tabla_h_deudorsbsdetalle']
        self.cons_h_sectorista = prms_spark['prm_spark_tabla_h_sectorista']
        self.cons_h_cliente = prms_spark['prm_spark_tabla_h_cliente']
        self.cons_h_party = prms_spark['prm_spark_tabla_h_party']
        self.cons_f_reportegestion = prms_spark['prm_spark_tabla_f_reportegestion']
        self.cons_mm_parametrogeneral = prms_spark['prm_spark_tabla_mm_parametrogeneral']

        self.cons_storage_level = StorageLevel(True, True, False, False, 1)
        self.cons_repartition = 1
        self.cons_format = "delta"
        self.cons_mode = "overwrite"
        self.cons_left_join = "left"
        self.cons_field_partition = 'codmes'
        self.cons_num_resta_meses_1 = 0
        self.cons_num_resta_meses_12 = 11


    def _logger_info(self, mensaje):
        print("::: " + mensaje)

    @staticmethod
    def read_data_lhcl(spark, schema_tabla):
        """
        Lectura de tabla en Catalog
        """
        try:
            # df = spark.read.table(schema_tabla)
            df = spark.read.parquet(schema_tabla)
            return df
        except Exception as e:
            raise Exception(f"Error en read_data_lhcl:\n{e}")

    @staticmethod
    def write_data_lhcl(df, w_repartition, w_partition, w_format, w_mode, schema_table):
        """
        Escritura de tabla en lhcl
        """
        try:
            (df
             .repartition(w_repartition)
             .write
             .partitionBy(w_partition)
             .format(w_format)
             .mode(w_mode)
             .insertInto(schema_table))
        except Exception as e:
            raise Exception(f"Error en write_data_lhcl:\n{e}")

    @property
    def col_current_datetime(self):
        """
        Genera la fecha actual
        """
        return datetime.now()

    @staticmethod
    def get_schema(schema) -> [list]:
        """
        Genera el esquema de dataframes
        """
        try:
            return [col(c.name).cast(c.dataType).alias(c.name) for c in schema]
        except Exception as e:
            raise Exception(f"Error en get_schema:\n{e}")

    @staticmethod
    def schema_hm_insumopuntuacionprospectoingresobdn():
        """
        Esquema de dataframes hm_insumopuntuacionprospectoingresobdn
        """
        return StructType([
            StructField("codclavepartycli", StringType(), nullable=True),
            StructField("codclavepartydeudorsbs", StringType(), nullable=True),
            StructField("tiproldeudorsbs", StringType(), nullable=True),
            StructField("codempsistemafinanciero", StringType(), nullable=True),
            StructField("codsbs", StringType(), nullable=True),
            StructField("codclaveunicocli", StringType(), nullable=True),
            StructField("codinternocomputacional", StringType(), nullable=True),
            StructField("codsector", StringType(), nullable=True),
            StructField("nbrempsistemafinanciero", StringType(), nullable=True),
            StructField("rcc_mto_deu_vig", DecimalType(23, 6), nullable=True),
            StructField("fecrutina", DateType(), nullable=True),
            StructField("fecactualizacionregistro", TimestampType(), nullable=True)
        ])

    @staticmethod
    def get_days(codmes_inicio, codmes_fin):
        """
        Obtiene el primer día de codmes_inicio y el último día de codmes_fin
        """
        try:
            # Obtener el primer día de codmes_inicio
            codmes_inicio = str(codmes_inicio)
            year_inicio = int(codmes_inicio[:4])
            month_inicio = int(codmes_inicio[4:])
            first_day = datetime(year_inicio, month_inicio, 1).date()

            # Obtener el último día de codmes_fin
            codmes_fin = str(codmes_fin)
            year_fin = int(codmes_fin[:4])
            month_fin = int(codmes_fin[4:])
            first_day_fin = datetime(year_fin, month_fin, 1).date()
            next_month = first_day_fin.replace(day=28) + timedelta(days=4)
            last_day = next_month - timedelta(days=next_month.day)

            return first_day, last_day
        except BaseException as e:
            raise Exception(":: Error en get_days :: \n:: Error: " + str(e))

    @staticmethod
    def get_union_dataframe(*dfs) -> DataFrame:
        """
        Union de los DataFrames
        """
        try:
            union_df = reduce(DataFrame.unionByName, dfs).dropDuplicates()
            return union_df
        except BaseException as e:
            raise Exception(":: Error en get_join_dataframe :: \n:: Error: " + str(e))

    @staticmethod
    def get_periodos_a_procesar(codmes_inicio, codmes_fin):
        """
        Crea arreglo de periodos a procesar
        """
        try:
            array_periodos = []
            periodo_inicio = datetime.strptime(codmes_inicio, "%Y%m")
            periodo_fin = datetime.strptime(codmes_fin, "%Y%m")
            for dt in rrule.rrule(rrule.MONTHLY, dtstart=periodo_inicio, until=periodo_fin):
                periodo_codmes = int(str(dt.date()).replace("-", "")[:6])
                array_periodos.append(periodo_codmes)
            return array_periodos
        except BaseException as e:
            raise Exception(":: Error en get_periodos_a_procesar :: \n:: Error: " + str(e))

    @staticmethod
    def restar_meses(meses, fecha):
        """
        Resta meses a codmes
        """
        try:
            resta_n_meses = int(meses)
            fecha = str(fecha)
            fecha_inicial = datetime.strptime(fecha, "%Y%m")
            resultado_fecha = fecha_inicial - relativedelta(months=resta_n_meses)
            fecha_fin = int(str(resultado_fecha).replace("-", "")[:6])
            return fecha_fin
        except BaseException as e:
            raise Exception(":: Error en restar_meses :: \n:: Error: " + str(e))

    @property
    def get_mm_parametrogeneral(self) -> DataFrame:
        """
        Obtiene datos de la tabla mm_parametrogeneral
        """
        try:
            filter_conditions = (col("codparametro") == lit('CODMES'))
            mm_parametrogeneral_df = self.read_data_lhcl(self.spark, self.cons_mm_parametrogeneral)
            return mm_parametrogeneral_df.filter(filter_conditions) \
                .select(col("codmesinicio"),
                        col("codmesfin")
                        )
        except BaseException as e:
            raise Exception(":: Error en get_mm_parametrogeneral :: \n" + str(e))

    @property
    def get_parametros(self):
        """
            Crea arreglo de periodos a procesar
        """
        try:
            array_periodos_proceso = []
            periodos = self.get_mm_parametrogeneral.first()
            if periodos:
                codmes_inicio = str(periodos['codmesinicio'])
                codmes_fin = str(periodos['codmesfin'])
                array_periodos_proceso = self.get_periodos_a_procesar(codmes_inicio, codmes_fin)
            return array_periodos_proceso
        except BaseException as e:
            raise Exception(":: Error en get_parametros :: \n" + str(e))

    @property
    def get_h_deudorsbsdetalle(self):
        """
            Obtiene datos de h_deudorsbsdetalle
        """
        try:
            h_deudorsbsdetalle_df = self.read_data_lhcl(self.spark, self.cons_h_deudorsbsdetalle)
            self.fechas = [row['fecdia'] for row in (h_deudorsbsdetalle_df
                                                     .filter(col("fecdia").between(self.first_day, self.last_day))
                                                     .groupBy(year("fecdia").alias("year"),
                                                              month("fecdia").alias("month"))
                                                     .agg(max(col("fecdia")).alias("fecdia"))
                                                     .select(col("fecdia"))
                                                     .toLocalIterator())]

            h_deudorsbsdetalle_df.filter(col("fecdia").isin(self.fechas))
            h_deudorsbsdetalle_df.show()


            return self.fechas
        except BaseException as e:
            raise Exception(":: Error en get_parametros :: \n" + str(e))

    @property
    def get_prospecto_ingreso(self) -> DataFrame:
        """
        Procesa prospecto ingreso
        """
        try:
            df = self.get_h_deudorsbsdetalle

            return df
        except Exception as e:
            raise Exception(f"Error en get_prospecto_ingreso:\n{e}")

    def process_data(self) -> None:
        self._logger_info(" >>> Inicia proceso ...")
        try:
            periodos_arr = self.get_parametros
            for periodo in periodos_arr:
                self._logger_info("Periodo en proceso: " + str(periodo))
                self.codmes_proceso = periodo
                self.codmes_inicio = self.restar_meses(self.cons_num_resta_meses_12, self.codmes_proceso)
                self.codmes_fin = self.restar_meses(self.cons_num_resta_meses_1, self.codmes_proceso)
                self.periodos = self.get_periodos_a_procesar(str(self.codmes_inicio), str(self.codmes_proceso))
                self.periodos.sort(reverse=True)

                print(self.codmes_proceso)
                print(self.codmes_inicio)
                print(self.codmes_fin)
                print(self.periodos)

                self.first_day, self.last_day = self.get_days(self.codmes_inicio, self.codmes_fin)
                print(self.first_day)
                print(self.last_day)

                prospecto_ingreso_df = self.get_prospecto_ingreso
                # prospecto_ingreso_df.persist(storageLevel=self.cons_storage_level)
                # prospecto_count = prospecto_ingreso_df.count()
                # self._logger_info(f"Registros procesados - {prospecto_count}")
                # prospecto_ingreso_df.show()
                print(prospecto_ingreso_df)

                # if prospecto_ingreso_df.head(1):
                #     self.write_data_lhcl(prospecto_ingreso_df,
                #                          self.cons_repartition,
                #                          self.cons_field_partition,
                #                          self.cons_format,
                #                          self.cons_mode,
                #                          self.cons_hm_insumopuntuacionprospectoingresobdn)
                # else:
                #     self._logger_info(f"Dataframe vacio, no se realizan cambios.")
                # prospecto_ingreso_df.unpersist()
        except Exception as e:
            self._logger_info(f"\nError en process_data:\n{e}")
        self._logger_info(" >>> Finaliza proceso...")

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC main()

# COMMAND ----------

def main():
    try:
        # dbutils.widgets.text("PRM_SPARK_FECHARUTINA", "2024-09-25")
        #
        # dbutils.widgets.text("PRM_SPARK_ESQUEMA_DDV_SEGINFOBCANEG", "catalog_lhcl_prod_bcp.bcp_ddv_adrmmgr_seginfobcaneg_v")
        # dbutils.widgets.text("PRM_SPARK_ESQUEMA_DDV_MATRIZVARIABLES", "catalog_lhcl_prod_bcp.bcp_ddv_matrizvariables_v")
        # dbutils.widgets.text("PRM_SPARK_ESQUEMA_DDV_INFCONSOLIDADOCLI", "catalog_lhcl_prod_bcp.bcp_ddv_rbmbcaneg_infconsolidadocli_v")
        # dbutils.widgets.text("PRM_SPARK_ESQUEMA_UDV_INT", "catalog_lhcl_prod_bcp.bcp_udv_int_v")
        #
        # dbutils.widgets.text("PRM_SPARK_TABLA_H_DEUDORSBSDETALLE", "h_deudorsbsdetalle")
        # dbutils.widgets.text("PRM_SPARK_TABLA_H_SECTORISTA", "h_sectorista")
        # dbutils.widgets.text("PRM_SPARK_TABLA_H_CLIENTE", "h_cliente")
        # dbutils.widgets.text("PRM_SPARK_TABLA_H_PARTY", "h_party")
        # dbutils.widgets.text("PRM_SPARK_TABLA_HM_DETCONCEPTORESUMENSALDO", "hm_detconceptoresumensaldo")
        # dbutils.widgets.text("PRM_SPARK_TABLA_HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN", "hm_insumopuntuacionprospectoingresobdn")
        # dbutils.widgets.text("PRM_SPARK_TABLA_MM_PARAMETROGENERAL", "mm_parametrogeneral")

        prms_spark = {
            # "prm_spark_fecharutina": dbutils.widgets.get("PRM_SPARK_FECHARUTINA"),
            #
            # "prm_spark_esquema_ddv_seginfobcaneg": dbutils.widgets.get("PRM_SPARK_ESQUEMA_DDV_SEGINFOBCANEG"),
            # "prm_spark_esquema_ddv_matrizvariables": dbutils.widgets.get("PRM_SPARK_ESQUEMA_DDV_MATRIZVARIABLES"),
            # "prm_spark_esquema_ddv_infconsolidadocli": dbutils.widgets.get("PRM_SPARK_ESQUEMA_DDV_INFCONSOLIDADOCLI"),
            # "prm_spark_esquema_udv_int": dbutils.widgets.get("PRM_SPARK_ESQUEMA_UDV_INT"),
            #
            # "prm_spark_tabla_h_deudorsbsdetalle": dbutils.widgets.get("PRM_SPARK_TABLA_H_DEUDORSBSDETALLE"),
            # "prm_spark_tabla_h_sectorista": dbutils.widgets.get("PRM_SPARK_TABLA_H_SECTORISTA"),
            # "prm_spark_tabla_h_cliente": dbutils.widgets.get("PRM_SPARK_TABLA_H_CLIENTE"),
            # "prm_spark_tabla_h_party": dbutils.widgets.get("PRM_SPARK_TABLA_H_PARTY"),
            # "prm_spark_tabla_hm_detconceptoresumensaldo": dbutils.widgets.get("PRM_SPARK_TABLA_HM_DETCONCEPTORESUMENSALDO"),
            # "prm_spark_tabla_hm_insumopuntuacionprospectoingresobdn": dbutils.widgets.get("PRM_SPARK_TABLA_HM_INSUMOPUNTUACIONPROSPECTOINGRESOBDN"),
            # "prm_spark_tabla_mm_parametrogeneral": dbutils.widgets.get("PRM_SPARK_TABLA_MM_PARAMETROGENERAL")

            "prm_spark_tabla_h_deudorsbsdetalle": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\F_REPORTEGESTION',
            "prm_spark_tabla_h_sectorista": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\H_SECTORISTA',
            "prm_spark_tabla_h_cliente": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\H_CLIENTE',
            "prm_spark_tabla_h_party": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\H_PARTY',
            "prm_spark_tabla_f_reportegestion": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\F_REPORTEGESTION',
            "prm_spark_tabla_mm_parametrogeneral": 'C:\\Users\\T30403\\Documents\\PROSPECTO_NEGOCIO\\inputs\\MM_PARAMETROGENERAL'

        }

        prospecto_ingreso = ProspectoIngresoBDN(prms_spark)
        prospecto_ingreso.process_data()
    except Exception as e:
        # dbutils.notebook.exit("Error en main() \n" + str(e))
        print("Error en main() \n" + str(e))


# COMMAND ----------

if __name__ == '__main__':
    main()

# COMMAND ----------

# dbutils.notebook.exit(1)
